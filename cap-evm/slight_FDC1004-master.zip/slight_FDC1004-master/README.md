# slight_FDC1004
arduino library for TI FDC1004
